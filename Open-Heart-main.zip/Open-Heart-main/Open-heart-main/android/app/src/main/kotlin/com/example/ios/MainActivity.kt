package com.example.ios

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
